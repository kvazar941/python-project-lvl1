"""Module for interpreting a directory as a package."""
